﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetGame1.Engine
{
    public class AI : Punter
    {
        public AI()
        {
            this.Name = "AI";           
        }
    }
}
