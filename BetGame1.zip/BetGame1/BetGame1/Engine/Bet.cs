﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetGame1.Engine
{
    public class Bet
    {
        public int Amount;

        public Bike Bike;

        public Bet()
        {

        }
    }
}
