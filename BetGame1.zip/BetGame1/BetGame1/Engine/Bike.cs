﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BetGame1.Engine
{
    public class Bike
    {
        public string BikeName;

        public PictureBox MyPictureBox;

        public int RaceTrackLength;
    }
}
