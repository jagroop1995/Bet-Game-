﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetGame1.Engine
{
    public class Joe : Punter
    {
        public Joe()
        {
            this.Name = "Joe";
        }
    }
}
