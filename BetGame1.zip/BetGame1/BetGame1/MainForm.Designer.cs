﻿namespace BetGame1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.betPanel = new System.Windows.Forms.Panel();
            this.textPunter3 = new System.Windows.Forms.TextBox();
            this.textPunter2 = new System.Windows.Forms.TextBox();
            this.textPunter1 = new System.Windows.Forms.TextBox();
            this.numericBetAmount = new System.Windows.Forms.NumericUpDown();
            this.lblBet = new System.Windows.Forms.Label();
            this.lblMax = new System.Windows.Forms.Label();
            this.numericBikeNumber = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.radioPunter3 = new System.Windows.Forms.RadioButton();
            this.radioPunter2 = new System.Windows.Forms.RadioButton();
            this.radioPunter1 = new System.Windows.Forms.RadioButton();
            this.btnProcess = new System.Windows.Forms.Button();
            this.picTrack = new System.Windows.Forms.PictureBox();
            this.picBike4 = new System.Windows.Forms.PictureBox();
            this.picBike3 = new System.Windows.Forms.PictureBox();
            this.picBike2 = new System.Windows.Forms.PictureBox();
            this.picBike1 = new System.Windows.Forms.PictureBox();
            this.betPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericBetAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericBikeNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTrack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBike4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBike3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBike2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBike1)).BeginInit();
            this.SuspendLayout();
            // 
            // betPanel
            // 
            this.betPanel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.betPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.betPanel.Controls.Add(this.textPunter3);
            this.betPanel.Controls.Add(this.textPunter2);
            this.betPanel.Controls.Add(this.textPunter1);
            this.betPanel.Controls.Add(this.numericBetAmount);
            this.betPanel.Controls.Add(this.lblBet);
            this.betPanel.Controls.Add(this.lblMax);
            this.betPanel.Controls.Add(this.numericBikeNumber);
            this.betPanel.Controls.Add(this.label1);
            this.betPanel.Controls.Add(this.radioPunter3);
            this.betPanel.Controls.Add(this.radioPunter2);
            this.betPanel.Controls.Add(this.radioPunter1);
            this.betPanel.Location = new System.Drawing.Point(12, 12);
            this.betPanel.Name = "betPanel";
            this.betPanel.Size = new System.Drawing.Size(1445, 179);
            this.betPanel.TabIndex = 0;
            // 
            // textPunter3
            // 
            this.textPunter3.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPunter3.Location = new System.Drawing.Point(620, 126);
            this.textPunter3.Name = "textPunter3";
            this.textPunter3.Size = new System.Drawing.Size(818, 43);
            this.textPunter3.TabIndex = 10;
            // 
            // textPunter2
            // 
            this.textPunter2.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPunter2.Location = new System.Drawing.Point(620, 69);
            this.textPunter2.Name = "textPunter2";
            this.textPunter2.Size = new System.Drawing.Size(818, 43);
            this.textPunter2.TabIndex = 9;
            // 
            // textPunter1
            // 
            this.textPunter1.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPunter1.Location = new System.Drawing.Point(620, 15);
            this.textPunter1.Name = "textPunter1";
            this.textPunter1.Size = new System.Drawing.Size(818, 43);
            this.textPunter1.TabIndex = 8;
            // 
            // numericBetAmount
            // 
            this.numericBetAmount.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericBetAmount.Location = new System.Drawing.Point(509, 127);
            this.numericBetAmount.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericBetAmount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericBetAmount.Name = "numericBetAmount";
            this.numericBetAmount.Size = new System.Drawing.Size(72, 43);
            this.numericBetAmount.TabIndex = 7;
            this.numericBetAmount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblBet
            // 
            this.lblBet.AutoSize = true;
            this.lblBet.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBet.Location = new System.Drawing.Point(178, 126);
            this.lblBet.Name = "lblBet";
            this.lblBet.Size = new System.Drawing.Size(79, 36);
            this.lblBet.TabIndex = 6;
            this.lblBet.Text = "Bets";
            // 
            // lblMax
            // 
            this.lblMax.AutoSize = true;
            this.lblMax.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMax.Location = new System.Drawing.Point(178, 70);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(239, 36);
            this.lblMax.TabIndex = 5;
            this.lblMax.Text = "Max Bet is $50";
            // 
            // numericBikeNumber
            // 
            this.numericBikeNumber.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericBikeNumber.Location = new System.Drawing.Point(509, 15);
            this.numericBikeNumber.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericBikeNumber.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericBikeNumber.Name = "numericBikeNumber";
            this.numericBikeNumber.Size = new System.Drawing.Size(72, 43);
            this.numericBikeNumber.TabIndex = 4;
            this.numericBikeNumber.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(178, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 36);
            this.label1.TabIndex = 3;
            this.label1.Text = "On Bike Number";
            // 
            // radioPunter3
            // 
            this.radioPunter3.AutoSize = true;
            this.radioPunter3.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioPunter3.Location = new System.Drawing.Point(18, 127);
            this.radioPunter3.Name = "radioPunter3";
            this.radioPunter3.Size = new System.Drawing.Size(164, 40);
            this.radioPunter3.TabIndex = 2;
            this.radioPunter3.TabStop = true;
            this.radioPunter3.Text = "Punter 3";
            this.radioPunter3.UseVisualStyleBackColor = true;
            this.radioPunter3.CheckedChanged += new System.EventHandler(this.punter_CheckedChanged);
            // 
            // radioPunter2
            // 
            this.radioPunter2.AutoSize = true;
            this.radioPunter2.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioPunter2.Location = new System.Drawing.Point(18, 68);
            this.radioPunter2.Name = "radioPunter2";
            this.radioPunter2.Size = new System.Drawing.Size(164, 40);
            this.radioPunter2.TabIndex = 1;
            this.radioPunter2.TabStop = true;
            this.radioPunter2.Text = "Punter 2";
            this.radioPunter2.UseVisualStyleBackColor = true;
            this.radioPunter2.CheckedChanged += new System.EventHandler(this.punter_CheckedChanged);
            // 
            // radioPunter1
            // 
            this.radioPunter1.AutoSize = true;
            this.radioPunter1.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioPunter1.Location = new System.Drawing.Point(18, 13);
            this.radioPunter1.Name = "radioPunter1";
            this.radioPunter1.Size = new System.Drawing.Size(164, 40);
            this.radioPunter1.TabIndex = 0;
            this.radioPunter1.TabStop = true;
            this.radioPunter1.Text = "Punter 1";
            this.radioPunter1.UseVisualStyleBackColor = true;
            this.radioPunter1.CheckedChanged += new System.EventHandler(this.punter_CheckedChanged);
            // 
            // btnProcess
            // 
            this.btnProcess.Font = new System.Drawing.Font("Consolas", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProcess.Location = new System.Drawing.Point(12, 209);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(1445, 67);
            this.btnProcess.TabIndex = 1;
            this.btnProcess.Text = "Place Bet";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // picTrack
            // 
            this.picTrack.Image = global::BetGame1.Properties.Resources.track;
            this.picTrack.Location = new System.Drawing.Point(148, 318);
            this.picTrack.Name = "picTrack";
            this.picTrack.Size = new System.Drawing.Size(1304, 392);
            this.picTrack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTrack.TabIndex = 6;
            this.picTrack.TabStop = false;
            // 
            // picBike4
            // 
            this.picBike4.Image = global::BetGame1.Properties.Resources.bike4;
            this.picBike4.Location = new System.Drawing.Point(12, 619);
            this.picBike4.Name = "picBike4";
            this.picBike4.Size = new System.Drawing.Size(130, 70);
            this.picBike4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBike4.TabIndex = 5;
            this.picBike4.TabStop = false;
            // 
            // picBike3
            // 
            this.picBike3.Image = global::BetGame1.Properties.Resources.bike3;
            this.picBike3.Location = new System.Drawing.Point(12, 522);
            this.picBike3.Name = "picBike3";
            this.picBike3.Size = new System.Drawing.Size(130, 70);
            this.picBike3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBike3.TabIndex = 4;
            this.picBike3.TabStop = false;
            // 
            // picBike2
            // 
            this.picBike2.Image = global::BetGame1.Properties.Resources.bike2;
            this.picBike2.Location = new System.Drawing.Point(12, 429);
            this.picBike2.Name = "picBike2";
            this.picBike2.Size = new System.Drawing.Size(130, 70);
            this.picBike2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBike2.TabIndex = 3;
            this.picBike2.TabStop = false;
            // 
            // picBike1
            // 
            this.picBike1.Image = global::BetGame1.Properties.Resources.bike1;
            this.picBike1.Location = new System.Drawing.Point(12, 335);
            this.picBike1.Name = "picBike1";
            this.picBike1.Size = new System.Drawing.Size(130, 70);
            this.picBike1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBike1.TabIndex = 2;
            this.picBike1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1469, 741);
            this.Controls.Add(this.picBike4);
            this.Controls.Add(this.picBike3);
            this.Controls.Add(this.picBike2);
            this.Controls.Add(this.picBike1);
            this.Controls.Add(this.picTrack);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.betPanel);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bet Race Game";
            this.betPanel.ResumeLayout(false);
            this.betPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericBetAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericBikeNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTrack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBike4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBike3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBike2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBike1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel betPanel;
        private System.Windows.Forms.RadioButton radioPunter3;
        private System.Windows.Forms.RadioButton radioPunter2;
        private System.Windows.Forms.RadioButton radioPunter1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericBikeNumber;
        private System.Windows.Forms.Label lblMax;
        private System.Windows.Forms.NumericUpDown numericBetAmount;
        private System.Windows.Forms.Label lblBet;
        private System.Windows.Forms.TextBox textPunter3;
        private System.Windows.Forms.TextBox textPunter2;
        private System.Windows.Forms.TextBox textPunter1;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.PictureBox picTrack;
        private System.Windows.Forms.PictureBox picBike4;
        private System.Windows.Forms.PictureBox picBike3;
        private System.Windows.Forms.PictureBox picBike2;
        private System.Windows.Forms.PictureBox picBike1;
    }
}

