﻿using BetGame1.Engine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BetGame1
{
    public partial class MainForm : Form
    {
        Bike[] bikes = new Bike[4];
        Punter[] punters = new Punter[3];
        Bike winner;

        Timer[] timers = new Timer[4];
        int stopCounter;


        public MainForm()
        {
            InitializeComponent();
            InitializeData();
            InitializeBetDetails();
        }

        private void InitializeData()
        {
            // Initialize All Bike Details
            bikes[0] = new Bike() { BikeName = "Bike 1", RaceTrackLength = 1015, MyPictureBox = picBike1 };
            bikes[1] = new Bike() { BikeName = "Bike 2", RaceTrackLength = 1015, MyPictureBox = picBike2 };
            bikes[2] = new Bike() { BikeName = "Bike 3", RaceTrackLength = 1015, MyPictureBox = picBike3 };
            bikes[3] = new Bike() { BikeName = "Bike 4", RaceTrackLength = 1015, MyPictureBox = picBike4 };
            punters[0] = Factory.GetAPunter(1);
            punters[1] = Factory.GetAPunter(2);
            punters[2] = Factory.GetAPunter(3);
            // Initialize First Punter Details
            punters[0].MyLabel = lblBet;
            punters[0].MyRadioButton = radioPunter1;
            punters[0].MyText = textPunter1;
            punters[0].MyRadioButton.Text = punters[0].Name;

            // Initialize Second Punter Details
            punters[1].MyLabel = lblBet;
            punters[1].MyRadioButton = radioPunter2;
            punters[1].MyText = textPunter2;
            punters[1].MyRadioButton.Text = punters[1].Name;

            // Initialize Third Punter Details
            punters[2].MyLabel = lblBet;
            punters[2].MyRadioButton = radioPunter3;
            punters[2].MyText = textPunter3;
            punters[2].MyRadioButton.Text = punters[2].Name;

            // Set The Bike Number Numeric Up Down
            numericBikeNumber.Minimum = 1;
            numericBikeNumber.Maximum = 4;
            numericBikeNumber.Value = 1;
        }

        private void punter_CheckedChanged(object sender, EventArgs e)
        {
            InitializeBetDetails();
        }

        private void InitializeBetDetails()
        {
            foreach (Punter punter in punters)
            {
                if (punter.Busted)
                {
                    punter.MyText.Text = "BUSTED";
                }
                else
                {
                    if (punter.MyBet == null)
                    {
                        punter.MyText.Text = punter.Name + " hasn't placed a bet";
                    }
                    else
                    {
                        punter.MyText.Text = punter.Name + " bets $" + punter.MyBet.Amount + " on " + punter.MyBet.Bike.BikeName;
                    }
                    if (punter.MyRadioButton.Checked)
                    {
                        lblMax.Text = "Max Bet is $" + punter.Cash.ToString();
                        btnProcess.Text = "Place Bet for " + punter.Name;
                        punter.MyLabel.Text = punter.Name + " Bets Amount $";
                        numericBetAmount.Minimum = 1;
                        numericBetAmount.Maximum = punter.Cash;
                        numericBetAmount.Value = 1;
                    }
                }
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if(btnProcess.Text.Contains("Place"))
            {
                int count = 0;
                int total_active = 0;
                foreach (Punter punter in punters)
                {
                    if (!punter.Busted)
                    {
                        total_active++;
                    }
                    if (punter.MyRadioButton.Checked)
                    {
                        if (punter.MyBet == null)
                        {
                            int number = (int)numericBikeNumber.Value;
                            int amount = (int)numericBetAmount.Value;
                            bool alreadyPlaced = false;
                            foreach (Punter pun in punters)
                            {
                                if (pun.MyBet != null && pun.MyBet.Bike == bikes[number - 1])
                                {
                                    alreadyPlaced = true;
                                    break;
                                }
                            }
                            if (alreadyPlaced)
                            {
                                MessageBox.Show("This Bike Number is Already Taken. Try With Different Bike Number");
                            }
                            else
                            {
                                punter.MyBet = new Bet() { Amount = amount, Bike = bikes[number - 1] };
                            }

                        }
                        else
                        {
                            MessageBox.Show("You Already Place Bet for " + punter.Name);
                        }
                    }
                    if (punter.MyBet != null)
                    {
                        count++;
                    }
                }
                InitializeBetDetails();
                if (count == total_active)
                {
                    btnProcess.Text = "Start The Race";
                    betPanel.Enabled = false;
                }                
            }
            else if (btnProcess.Text.Contains("Start"))
            {
                for (int index = 0; index < timers.Length; index++)
                {
                    timers[index] = new Timer();
                    timers[index].Interval = 15;
                    timers[index].Tick += Race_Tick;
                    timers[index].Start();
                }
            }
            else if (btnProcess.Text.Contains("Game"))
            {
                MessageBox.Show("Game Over!!! Restart The Application Again to Enjoy Betting...");
                Application.Exit();
            }
        }

        private void Race_Tick(object sender, EventArgs e)
        {
            if (sender is Timer)
            {
                Timer timer = sender as Timer;
                int index = 0;
                while (index < timers.Length)
                {
                    if (timers[index] == timer)
                    {
                        break;
                    }
                    index++;
                }
                PictureBox picture = bikes[index].MyPictureBox;
                if (picture.Location.X + picture.Width > bikes[index].RaceTrackLength)
                {
                    timer.Stop();
                    stopCounter++;
                    if (winner == null)
                    {
                        winner = bikes[index];                        
                    }
                }
                else
                {
                    int jump = new Random().Next(1, 15);
                    picture.Location = new Point(picture.Location.X + jump, picture.Location.Y);
                }

            }
            if (stopCounter == timers.Length)
            {
                MessageBox.Show(winner.BikeName + " is Won!!!");
                InitializeBetDetails();
                foreach (Punter punter in punters)
                {
                    if (punter.MyBet != null)
                    {
                        if (punter.MyBet.Bike == winner)
                        {
                            punter.Cash += punter.MyBet.Amount;
                            punter.MyText.Text = punter.Name + " Won and now has $" + punter.Cash;
                            punter.Winner = true;
                        }
                        else
                        {
                            punter.Cash -= punter.MyBet.Amount;
                            if (punter.Cash == 0)
                            {
                                punter.MyText.Text = "BUSTED";
                                punter.Busted = true;
                                punter.MyRadioButton.Enabled = false;
                            }
                            else
                            {
                                punter.MyText.Text = punter.Name + " Lost and now has $" + punter.Cash;
                            }
                        }
                    }
                }
                winner = null;
                stopCounter = 0;
                timers = new Timer[4];                
                int count = 0;
                foreach (Punter punter in punters)
                {
                    if (punter.Busted)
                    {
                        count++;
                    }
                    if (punter.MyRadioButton.Enabled && punter.MyRadioButton.Checked)
                    {
                        lblMax.Text = "Max Bet is $" + punter.Cash;
                    }
                    punter.MyBet = null;
                    punter.Winner = false;
                }
                if (count == punters.Length)
                {
                    btnProcess.Text = "Game Over";
                    
                }
                else
                {
                    betPanel.Enabled = true;
                }
                foreach (Bike bike in bikes)
                {
                    bike.MyPictureBox.Location = new Point(12, bike.MyPictureBox.Location.Y);
                }
            }
        }
    }
}
