﻿using System;
using BetGame1.Engine;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTesting
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestOne()
        {
            Punter punter = Factory.GetAPunter(5);
            bool result = punter is AI;
            Assert.AreEqual(result, true);
        }
    }
}
